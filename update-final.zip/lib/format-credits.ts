export function formatCredits(credits: number): string {
  return Math.floor(credits).toLocaleString();
}
