"use client"

import { ReactNode } from 'react'

export function WalletProvider({ children }: { children: ReactNode }) {
  return <>{children}</>
}
