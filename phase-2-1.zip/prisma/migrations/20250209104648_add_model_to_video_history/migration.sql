-- AlterTable
ALTER TABLE "video_generation_history" ADD COLUMN     "model" TEXT NOT NULL DEFAULT 'video-01';
