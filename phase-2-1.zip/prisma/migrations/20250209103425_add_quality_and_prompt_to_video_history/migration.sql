-- AlterTable
ALTER TABLE "video_generation_history" ADD COLUMN     "prompt" TEXT,
ADD COLUMN     "quality" TEXT;
