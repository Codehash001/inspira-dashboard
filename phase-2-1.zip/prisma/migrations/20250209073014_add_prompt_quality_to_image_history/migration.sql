-- AlterTable
ALTER TABLE "image_generation_history" ADD COLUMN     "prompt" TEXT,
ADD COLUMN     "quality" TEXT;
